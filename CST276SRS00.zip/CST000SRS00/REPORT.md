Name: Andrew Doser

Unresolved Issues: There are no unresolved errors. 

Notes: Built and ran the program. Program Exitted on 0. Checked the error list for warnings, found nothing. 

###
